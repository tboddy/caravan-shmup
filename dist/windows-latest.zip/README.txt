butcher3068 pre-alpha
2017 t.boddy/decontrol
saint petersburg, florida

supported controllers:
keyboard
neo-geo x
a stick i made

might work:
xbox 360

gpl2
developed on archlinux